import { PortableTextBlock } from 'sanity'

import { Section } from '../inspector/components/InspectorBody'
import { checkObjectForKeys } from './checkObjectForKeys'

export const getEmbeddedFields = (
  section: Section,
  fieldNames: string[],
): undefined | { field: string; value: unknown[] | PortableTextBlock[] }[] => {
  // check if other fields in this section are defined in fieldNames
  const embeddedFields = checkObjectForKeys(section, fieldNames)
  if (embeddedFields.length === 0) {
    return undefined
  }
  return (
    embeddedFields
      .flatMap((field) => {
        const value = section[field]
        return Array.isArray(value) ? [{ field, value }] : []
      })
  )
}
